# Aurin Bose - Data Analyst Portfolio

## Overview
A modern, professional portfolio website showcasing data analytics expertise and experience.

## Features
- Responsive design for all devices
- Dark theme with blue/teal accents
- Smooth scrolling navigation
- Interactive animations
- Contact form with validation
- Mobile-friendly hamburger menu
- Professional sections: About, Skills, Experience, Projects, Certifications

## Setup Instructions
1. Extract all files to your desired directory
2. Open `index.html` in a web browser
3. For local development, use a local server (Live Server extension in VS Code recommended)

## File Structure
- `index.html` - Main HTML file with all content sections
- `style.css` - Complete CSS styling with responsive design
- `app.js` - JavaScript for interactions and animations
- `README.md` - This file with setup instructions

## Customization
### To add your own photo:
1. Replace the placeholder divs in HTML with `<img>` tags
2. Add your image files to the project directory
3. Update the `src` attributes in the HTML

### To modify colors:
1. Edit the CSS variables in the `:root` section of `style.css`
2. Main colors: `--primary-color`, `--secondary-color`, `--accent-color`

### To update content:
1. Edit the text content directly in `index.html`
2. Update projects, experience, and certifications as needed

## Technologies Used
- HTML5
- CSS3 (Flexbox, Grid, Animations)
- Vanilla JavaScript
- Google Fonts (Inter)

## Browser Support
- Chrome, Firefox, Safari, Edge (modern versions)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance
- Optimized images (when added)
- Minimal JavaScript footprint
- CSS animations with reduced motion support
- Responsive design for fast mobile loading

## Contact
For questions about this portfolio template, contact: aurinbose@gmail.com
